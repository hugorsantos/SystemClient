package br.com.SystemClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SystemClientApplication.class, args);
	}

}
