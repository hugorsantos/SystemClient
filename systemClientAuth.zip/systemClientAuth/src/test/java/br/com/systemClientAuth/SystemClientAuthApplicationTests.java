package br.com.systemClientAuth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemClientAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
