package br.com.systemClientAuth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemClientAuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(SystemClientAuthApplication.class, args);
	}

}
